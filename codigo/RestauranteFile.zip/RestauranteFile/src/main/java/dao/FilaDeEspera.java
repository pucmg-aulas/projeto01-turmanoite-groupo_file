package dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import model.*;

/**
 *
 * @author danil
 */
public class FilaDeEspera extends AbstractDAO implements Serializable {

    private List<Requisicao> filaDeEspera;
    private static FilaDeEspera instance;

    private final String arq = "./RestauranteFile/src/main/java/data/FilaDeEspera.dat";

    private FilaDeEspera() {
        this.filaDeEspera = new ArrayList<>();
        carregaAtendimentos();
    }

    public static FilaDeEspera getInstance() {
        if (instance == null) {
            instance = new FilaDeEspera();
        }
        return instance;
    }

    public void addAtendimento(Requisicao atendimento) {
        this.filaDeEspera.add(atendimento);
        grava();
    }

    private void carregaAtendimentos() {
        this.filaDeEspera = super.leitura(arq);
    }

    private void grava() {
        super.grava(arq, filaDeEspera);
    }

    public List<Requisicao> getAtendimentos() {
        return filaDeEspera;
    }

    public void excluirAtendimento(Requisicao atendimento) {
        filaDeEspera.remove(atendimento);
        grava();
    }

   

    public boolean altera(Requisicao atendimentoExistente, String nome) {
        try {
            ArrayList<Requisicao> listaTemp = new ArrayList<Requisicao>();

            for (Iterator<Requisicao> it = filaDeEspera.iterator(); it.hasNext();) {
                Requisicao atendimento = it.next();
                if (!atendimento.getCliente().getNome().equals(nome)) {
                    listaTemp.add(atendimento);
                } else {
                    listaTemp.add(atendimentoExistente);
                }
            }

            filaDeEspera.removeAll(filaDeEspera);
            filaDeEspera.addAll(listaTemp);
            grava();

            return true;

        } catch (Exception e) {
            return false;
        }
    }
}
