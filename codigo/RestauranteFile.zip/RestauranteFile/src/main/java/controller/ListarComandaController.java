package controller;

import model.*;
import view.*;
import javax.swing.table.DefaultTableModel;

public class ListarComandaController {
    private final ListarComandaView view;
    private final Requisicao requisicao;

    public ListarComandaController(Requisicao requisicao) {
        this.view = new ListarComandaView();
        this.requisicao = requisicao;

        carregaTabela();

        this.view.setTitle("Comanda do Cliente " + requisicao.getCliente().getNome());
        this.view.setVisible(true);
    }

    private void carregaTabela() {
        DefaultTableModel model = new DefaultTableModel(
                new Object[] { "Quantidade", "Item", "Valor Unitário", "Quantidade", "Valor Total" }, 0);

        for (Pedido pedido : requisicao.getComanda().getPedidos()) {
            model.addRow(new Object[] {
                pedido.getQuantidade(),
                pedido.getAlimento().getNome(),
                pedido.getAlimento().getValor(),
                pedido.getQuantidade(),
                pedido.getValorTotal()
            });
        }

        view.getTblComanda().setModel(model);
    }
}
