package controller;

import dao.*;
import model.*;
import view.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.time.LocalDate;
import java.time.LocalTime;

public class FecharContaController {
    private final FecharContaView view;
    private final Requisicao requisicao;
    private final Requisicoes requisicoes;
    private final Clientes clientes;
    private final Mesas mesas;
    private final Pagamentos pagamentos;

    public FecharContaController(Requisicao requisicao) {
        this.requisicao = requisicao;
        this.view = new FecharContaView();
        this.clientes = Clientes.getInstance();
        this.requisicoes = Requisicoes.getInstance();
        this.mesas = Mesas.getInstance();
        this.pagamentos = Pagamentos.getInstance();

        this.view.getBtnFechar().addActionListener(e -> encerrarRequisicao());
        this.view.getBtnCancelar().addActionListener(e -> cancelar());
        this.view.getBtnExcluir().addActionListener(e -> excluirItem());


        carregaTela();
        this.view.setVisible(true);
    }

    private void carregaTela() {
        view.getTxtValor().setText(String.format("%.2f", requisicao.getComanda().calculaValor()));

        conta();
    }

    private void conta() {
        DefaultTableModel model = new DefaultTableModel(
            new Object[] { "Item", "Quantidade", "Valor", "Valor Total" }, 0);

        for (Pedido p : requisicao.getComanda().getPedidos()) {
        String[] linha = p.toString().split("%");

        if (linha.length >= 4) {
            model.addRow(new Object[] { linha[0], linha[1], linha[2], linha[3] });
        } else {
            System.out.println("Erro: O pedido não contém todas as partes esperadas. Dados: " + p.toString());
        }
    }

    view.getTblConta().setModel(model);
    }

    private void excluirItem() {
        int linha = view.getTblConta().getSelectedRow();
        if (linha >= 0) {
            requisicao.getComanda().getPedidos().remove(linha);
            requisicoes.altera(requisicao, requisicao.getCliente());
            carregaTela();
        }
    }

    private void encerrarRequisicao() {
        String nome = requisicao.getCliente().getNome();
        int option = JOptionPane.showConfirmDialog(view, "Deseja encerrar o atendimento ?");

        if (option == JOptionPane.YES_OPTION) {
            try {
                
                clientes.excluirCliente(clientes.buscarClientePorNome(nome).orElseThrow(() -> new Exception("Cliente não encontrado")));
                mesas.buscarMesaPorNumero(requisicao.getMesa().getNumero()).setOcupada(false);
                requisicoes.excluirRequisicao(requisicao);

                requisicao.setHoraSaida(LocalTime.now());
                requisicao.setMetodoPagamento(getMetodoPagamento());
               

                double valorFinal = requisicao.getComanda().calculaValor() -
                requisicao.getMetodoPagamento().calcularDesconto(requisicao.getComanda().calculaValor());
                LocalDate dataVencimento = LocalDate.now().plusDays(requisicao.getMetodoPagamento().getPrazoDias());
                
                pagamentos.addPagamento(new Pagamento(valorFinal, dataVencimento));

                JOptionPane.showMessageDialog(view, "Atendimento encerrado!");

                cancelar();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(view, "Erro ao encerrar atendimento: " + e.getMessage());
            }
        }
    }

    private MetodoPagamento getMetodoPagamento() {
        String pagamento = (String) this.view.getComboPagamento().getSelectedItem();
        switch (pagamento) {
            case "Crédito":
                return new Credito();
            case "Debito":
                return new Debito();
            case "Dinheiro":
                return new Dinheiro();
            case "Pix":
                return new Debito();
            default:
                return new Credito();
        }
    }

    private void cancelar() {
        this.view.dispose();
    }
}
