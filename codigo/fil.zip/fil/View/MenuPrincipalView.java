import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuPrincipalView extends JFrame {
    private RestauranteController controller;

    public MenuPrincipalView(RestauranteController controller) {
        this.controller = controller;
        initialize();
    }

    private void initialize() {
        setTitle("Restaurante");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 300, 200);
        getContentPane().setLayout(null);

        JButton btnAdicionarPedido = new JButton("Adicionar Pedido");
        btnAdicionarPedido.setBounds(10, 10, 150, 25);
        getContentPane().add(btnAdicionarPedido);

        JButton btnFecharConta = new JButton("Fechar Conta");
        btnFecharConta.setBounds(10, 45, 150, 25);
        getContentPane().add(btnFecharConta);

        JButton btnGerenciarMesas = new JButton("Gerenciar Mesas");
        btnGerenciarMesas.setBounds(10, 80, 150, 25);
        getContentPane().add(btnGerenciarMesas);

        btnAdicionarPedido.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AdicionarPedidoView adicionarPedidoView = new AdicionarPedidoView(controller);
                adicionarPedidoView.setVisible(true);
            }
        });

        btnFecharConta.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FecharContaView fecharContaView = new FecharContaView(controller);
                fecharContaView.setVisible(true);
            }
        });

        btnGerenciarMesas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GerenciarMesasView gerenciarMesasView = new GerenciarMesasView(controller);
                gerenciarMesasView.setVisible(true);
            }
        });
    }
}
