import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GerenciarMesasView extends JFrame {
    private RestauranteController controller;
    private JTextArea outputArea;

    public GerenciarMesasView(RestauranteController controller) {
        this.controller = controller;
        initialize();
    }

    private void initialize() {
        setTitle("Gerenciar Mesas");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        getContentPane().setLayout(null);

        JButton btnMostrarMesas = new JButton("Mostrar Mesas Disponíveis");
        btnMostrarMesas.setBounds(10, 10, 200, 25);
        getContentPane().add(btnMostrarMesas);

        JButton btnMostrarMesasOcupadas = new JButton("Mostrar Mesas Ocupadas");
        btnMostrarMesasOcupadas.setBounds(220, 10, 200, 25);
        getContentPane().add(btnMostrarMesasOcupadas);

        outputArea = new JTextArea();
        outputArea.setBounds(10, 45, 560, 300);
        getContentPane().add(outputArea);

        btnMostrarMesas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                outputArea.setText("");
                controller.mostrarMesasDisponiveis();
            }
        });

        btnMostrarMesasOcupadas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                outputArea.setText("");
                controller.mostrarMesasOcupadas();
            }
        });
    }

    public void appendToOutput(String text) {
        outputArea.append(text + "\n");
    }
}
