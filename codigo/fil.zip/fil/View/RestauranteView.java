import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class RestauranteView extends JFrame {
    private RestauranteController controller;
    private JTextField nomeClienteField;
    private JTextField quantidadePessoasField;
    private JTextField numeroMesaField;
    private JTextArea outputArea;

    public RestauranteView(RestauranteController controller) {
        this.controller = controller;
        initialize();
    }

    private void initialize() {
        setTitle("Restaurante");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        getContentPane().setLayout(null);

        // Campos de texto e labels para requisitar mesa
        JLabel lblNomeCliente = new JLabel("Nome do Cliente:");
        lblNomeCliente.setBounds(10, 10, 120, 25);
        getContentPane().add(lblNomeCliente);

        nomeClienteField = new JTextField();
        nomeClienteField.setBounds(140, 10, 200, 25);
        getContentPane().add(nomeClienteField);

        JLabel lblQuantidadePessoas = new JLabel("Quantidade de Pessoas:");
        lblQuantidadePessoas.setBounds(10, 45, 150, 25);
        getContentPane().add(lblQuantidadePessoas);

        quantidadePessoasField = new JTextField();
        quantidadePessoasField.setBounds(160, 45, 50, 25);
        getContentPane().add(quantidadePessoasField);

        JLabel lblNumeroMesa = new JLabel("Número da Mesa:");
        lblNumeroMesa.setBounds(10, 80, 120, 25);
        getContentPane().add(lblNumeroMesa);

        numeroMesaField = new JTextField();
        numeroMesaField.setBounds(140, 80, 50, 25);
        getContentPane().add(numeroMesaField);

        JButton btnRequisitarMesa = new JButton("Requisitar Mesa");
        btnRequisitarMesa.setBounds(10, 115, 150, 25);
        getContentPane().add(btnRequisitarMesa);

        btnRequisitarMesa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nome = nomeClienteField.getText();
                int quantidade = Integer.parseInt(quantidadePessoasField.getText());
                int numeroMesa = Integer.parseInt(numeroMesaField.getText());
                Cliente cliente = new Cliente(nome, quantidade);
                ArrayList<Cliente> clientes = new ArrayList<>();
                clientes.add(cliente);
                RequisicaoPorMesa requisicao = new RequisicaoPorMesa(numeroMesa, clientes);
                controller.getRequisicoes().add(requisicao);
                appendToOutput("Mesa requisitada: " + numeroMesa + " por " + nome + " com " + quantidade + " pessoas.");
            }
        });

        JButton btnAdicionarPedido = new JButton("Adicionar Pedido");
        btnAdicionarPedido.setBounds(10, 255, 150, 25);
        getContentPane().add(btnAdicionarPedido);

        JButton btnFecharConta = new JButton("Fechar Conta");
        btnFecharConta.setBounds(10, 290, 150, 25);
        getContentPane().add(btnFecharConta);

        JButton btnGerenciarMesas = new JButton("Gerenciar Mesas");
        btnGerenciarMesas.setBounds(10, 325, 150, 25);
        getContentPane().add(btnGerenciarMesas);

        outputArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBounds(10, 150, 560, 100);
        getContentPane().add(scrollPane);

        btnAdicionarPedido.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AdicionarPedidoView adicionarPedidoView = new AdicionarPedidoView(controller);
                adicionarPedidoView.setVisible(true);
            }
        });

        btnFecharConta.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FecharContaView fecharContaView = new FecharContaView(controller);
                fecharContaView.setVisible(true);
            }
        });

        btnGerenciarMesas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GerenciarMesasView gerenciarMesasView = new GerenciarMesasView(controller);
                gerenciarMesasView.setVisible(true);
            }
        });
    }

    private void appendToOutput(String text) {
        outputArea.append(text + "\n");
    }

    public static void main(String[] args) {
        List<Mesa> mesas = new ArrayList<>();
        mesas.add(new Mesa(1, 4, false, 0.0));
        mesas.add(new Mesa(2, 2, false, 0.0));
        mesas.add(new Mesa(3, 6, false, 0.0));
        Restaurante restaurante = new Restaurante(mesas);
        List<RequisicaoPorMesa> requisicoes = new ArrayList<>();
        RestauranteController controller = new RestauranteController(restaurante, requisicoes);

        RestauranteView frame = new RestauranteView(controller);
        frame.setVisible(true);
    }
}
