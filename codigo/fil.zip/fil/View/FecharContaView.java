import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FecharContaView extends JFrame {
    private RestauranteController controller;
    private JTextField numeroMesaField;
    private JTextArea outputArea;

    public FecharContaView(RestauranteController controller) {
        this.controller = controller;
        initialize();
    }

    private void initialize() {
        setTitle("Fechar Conta");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 400, 200);
        getContentPane().setLayout(null);

        JLabel lblNumeroMesa = new JLabel("Número da Mesa:");
        lblNumeroMesa.setBounds(10, 10, 120, 25);
        getContentPane().add(lblNumeroMesa);

        numeroMesaField = new JTextField();
        numeroMesaField.setBounds(140, 10, 200, 25);
        getContentPane().add(numeroMesaField);
        numeroMesaField.setColumns(10);

        JButton btnFecharConta = new JButton("Fechar Conta");
        btnFecharConta.setBounds(10, 45, 150, 25);
        getContentPane().add(btnFecharConta);

        outputArea = new JTextArea();
        outputArea.setBounds(10, 80, 350, 80);
        getContentPane().add(outputArea);

        btnFecharConta.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int numeroMesa = Integer.parseInt(numeroMesaField.getText());
                controller.fecharConta(numeroMesa);
                appendToOutput("Conta da mesa " + numeroMesa + " fechada.");
            }
        });
    }

    private void appendToOutput(String text) {
        outputArea.append(text + "\n");
    }
}
