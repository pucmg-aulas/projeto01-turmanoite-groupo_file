import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdicionarPedidoView extends JFrame {
    private RestauranteController controller;
    private JTextField numeroMesaField;
    private JTextField nComidaField;
    private JTextField precoField;
    private JTextArea outputArea;

    public AdicionarPedidoView(RestauranteController controller) {
        this.controller = controller;
        initialize();
    }

    private void initialize() {
        setTitle("Adicionar Pedido");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 400, 300);
        getContentPane().setLayout(null);

        JLabel lblNumeroMesa = new JLabel("Número da Mesa:");
        lblNumeroMesa.setBounds(10, 10, 120, 25);
        getContentPane().add(lblNumeroMesa);

        numeroMesaField = new JTextField();
        numeroMesaField.setBounds(140, 10, 200, 25);
        getContentPane().add(numeroMesaField);
        numeroMesaField.setColumns(10);

        JLabel lblNComida = new JLabel("Número do Item:");
        lblNComida.setBounds(10, 45, 120, 25);
        getContentPane().add(lblNComida);

        nComidaField = new JTextField();
        nComidaField.setBounds(140, 45, 200, 25);
        getContentPane().add(nComidaField);
        nComidaField.setColumns(10);

        JLabel lblPreco = new JLabel("Preço:");
        lblPreco.setBounds(10, 80, 120, 25);
        getContentPane().add(lblPreco);

        precoField = new JTextField();
        precoField.setBounds(140, 80, 200, 25);
        getContentPane().add(precoField);
        precoField.setColumns(10);

        JButton btnAdicionarPedido = new JButton("Adicionar Pedido");
        btnAdicionarPedido.setBounds(10, 115, 150, 25);
        getContentPane().add(btnAdicionarPedido);

        outputArea = new JTextArea();
        outputArea.setBounds(10, 150, 350, 100);
        getContentPane().add(outputArea);

        btnAdicionarPedido.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int numeroMesa = Integer.parseInt(numeroMesaField.getText());
                int nComida = Integer.parseInt(nComidaField.getText());
                double preco = Double.parseDouble(precoField.getText());
                Menu menu = new Menu(nComida, preco);
                controller.adicionarPedido(numeroMesa, menu);
                appendToOutput("Pedido adicionado à mesa " + numeroMesa + ".");
            }
        });
    }

    private void appendToOutput(String text) {
        outputArea.append(text + "\n");
    }
}
