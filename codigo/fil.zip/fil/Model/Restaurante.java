import java.util.List;

public class Restaurante {
    private List<Mesa> mesas;

    public Restaurante(List<Mesa> mesas) {
        this.mesas = mesas;
    }

    public List<Mesa> getMesas() {
        return mesas;
    }

    public void setMesas(List<Mesa> mesas) {
        this.mesas = mesas;
    }

    public Mesa getMesaPorNumero(int numero) {
        for (Mesa mesa : mesas) {
            if (mesa.getNumeroMesa() == numero) {
                return mesa;
            }
        }
        return null;
    }
}
