public class Mesa {
    private int numeroMesa;
    private int quantidadeLugares;
    private boolean ocupada;
    private double valorConta;

    public Mesa(int numeroMesa, int quantidadeLugares, boolean ocupada, double valorConta) {
        this.numeroMesa = numeroMesa;
        this.quantidadeLugares = quantidadeLugares;
        this.ocupada = ocupada;
        this.valorConta = valorConta;
    }

    public int getNumeroMesa() {
        return numeroMesa;
    }

    public void setNumeroMesa(int numeroMesa) {
        this.numeroMesa = numeroMesa;
    }

    public int getQuantidadeLugares() {
        return quantidadeLugares;
    }

    public void setQuantidadeLugares(int quantidadeLugares) {
        this.quantidadeLugares = quantidadeLugares;
    }

    public boolean isOcupada() {
        return ocupada;
    }

    public void setOcupada(boolean ocupada) {
        this.ocupada = ocupada;
    }

    public double getValorConta() {
        return valorConta;
    }

    public void setValorConta(double valorConta) {
        this.valorConta = valorConta;
    }
}
