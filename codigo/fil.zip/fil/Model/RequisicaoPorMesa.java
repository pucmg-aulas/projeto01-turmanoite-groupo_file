import java.util.ArrayList;

public class RequisicaoPorMesa {
    private int numeroMesa;
    private ArrayList<Cliente> clientes;

    public RequisicaoPorMesa(int numeroMesa, ArrayList<Cliente> clientes) {
        this.numeroMesa = numeroMesa;
        this.clientes = clientes;
    }

    public int getNumeroMesa() {
        return numeroMesa;
    }

    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public void setNumeroMesa(int numeroMesa) {
        this.numeroMesa = numeroMesa;
    }

    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }
}
