

import java.util.ArrayList;
import java.util.List;


public class Main {
    public static void main(String[] args) {
        List<Mesa> mesas = new ArrayList<>();
        mesas.add(new Mesa(1, 4, false, 0.0));
        mesas.add(new Mesa(2, 2, false, 0.0));
        mesas.add(new Mesa(3, 2, false, 0.0));
        mesas.add(new Mesa(4, 2, false, 0.0));
        mesas.add(new Mesa(5, 2, false, 0.0));
        mesas.add(new Mesa(6, 2, false, 0.0));
        mesas.add(new Mesa(7, 2, false, 0.0));
        mesas.add(new Mesa(8, 2, false, 0.0));
        mesas.add(new Mesa(9, 2, false, 0.0));
        mesas.add(new Mesa(10, 2, false, 0.0));

        Restaurante restaurante = new Restaurante(mesas);
        List<RequisicaoPorMesa> requisicoes = new ArrayList<>();
        RestauranteController controller = new RestauranteController(restaurante, requisicoes);

        MenuPrincipalView mainMenu = new MenuPrincipalView(controller);
        mainMenu.setVisible(true);
    }
}
