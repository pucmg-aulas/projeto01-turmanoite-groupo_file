
import java.util.ArrayList;
import java.util.List;

public class RestauranteController {
    private Restaurante restaurante;
    private List<RequisicaoPorMesa> requisicoes;

    public RestauranteController(Restaurante restaurante, List<RequisicaoPorMesa> requisicoes) {
        this.restaurante = restaurante;
        this.requisicoes = requisicoes;
    }

    public void adicionarPedido(int numeroMesa, Menu menu) {
        Mesa mesa = restaurante.getMesaPorNumero(numeroMesa);
        if (mesa != null) {
            Conta conta = new Conta(numeroMesa);
            conta.adicionarPedido(menu);
            mesa.setOcupada(true);
            mesa.setValorConta(conta.calcularTotal());
        } else {
            System.out.println("Mesa não encontrada.");
        }
    }

    public void fecharConta(int numeroMesa) {
        Mesa mesa = restaurante.getMesaPorNumero(numeroMesa);
        if (mesa != null) {
            Conta conta = new Conta(numeroMesa);
            conta.fecharConta();
            mesa.setOcupada(false);
            mesa.setValorConta(0.0);
        } else {
            System.out.println("Mesa não encontrada.");
        }
    }

    public void mostrarMesasDisponiveis() {
        for (Mesa mesa : restaurante.getMesas()) {
            if (!mesa.isOcupada()) {
                System.out.println("Mesa " + mesa.getNumeroMesa() + " está disponível.");
            }
        }
    }

    public void mostrarMesasOcupadas() {
        for (Mesa mesa : restaurante.getMesas()) {
            if (mesa.isOcupada()) {
                System.out.println("Mesa " + mesa.getNumeroMesa() + " está ocupada.");
            }
        }
    }

    public Restaurante getRestaurante() {
        return restaurante;
    }

    public List<RequisicaoPorMesa> getRequisicoes() {
        return requisicoes;
    }

    public void setRestaurante(Restaurante restaurante) {
        this.restaurante = restaurante;
    }

    public void setRequisicoes(List<RequisicaoPorMesa> requisicoes) {
        this.requisicoes = requisicoes;
    }
}
